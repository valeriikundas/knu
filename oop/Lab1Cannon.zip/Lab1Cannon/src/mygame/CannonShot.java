package mygame;
import com.jme3.app.SimpleApplication;
import com.jme3.asset.TextureKey;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.font.BitmapText;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.material.Material;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;
import com.jme3.scene.shape.Sphere;
import com.jme3.scene.shape.Sphere.TextureMode;
import com.jme3.texture.Texture;
import com.jme3.texture.Texture.WrapMode;
import com.jme3.math.ColorRGBA;
public class CannonShot extends SimpleApplication {


  /** Prepare the Physics Application State (jBullet) */
  private BulletAppState bulletAppState;

  /** Prepare Materials */
  private Material stoneMat;
  private Material floorMat;

  /** Prepare geometries and physical nodes for bricks and cannon balls. */
  private RigidBodyControl    ballPhy;
  private Sphere sphere;
  private RigidBodyControl    floorPhy;
  private Box    floor;
  
  /**
   * Every time the shoot action is triggered, a new cannon ball is produced.
   * The ball is set up to fly from the camera position in the camera direction.
   */
  private ActionListener actionListener = new ActionListener() {
    public void onAction(String name, boolean keyPressed, float tpf) {
      if (name.equals("shoot") && !keyPressed) {
        makeCannonBall();
      }
    }
  };

  @Override
  public void simpleInitApp() {
        //  Box box2 = new Box(1,1,1);
       // Geometry red = new Geometry("Box", box2);
       // red.setLocalTranslation(new Vector3f(0,0,0));
      //  Material mat2 = new Material(assetManager,
       //         "Common/MatDefs/Misc/Unshaded.j3md");
      //  mat2.setColor("Color", ColorRGBA.Blue);
      //  red.setMaterial(mat2);
       // rootNode.attachChild(red);
    /** Set up Physics Game */
    sphere = new Sphere(32, 32, 0.4f, true, false);
    sphere.setTextureMode(TextureMode.Projected);
    /** Initialize the floor geometry */
    floor = new Box(80f, 0.1f, 40f);
    floor.scaleTextureCoordinates(new Vector2f(3, 6));
    bulletAppState = new BulletAppState();
    stateManager.attach(bulletAppState);
    //bulletAppState.getPhysicsSpace().enableDebug(assetManager);
    /** Configure cam to look at scene */
    cam.setLocation(new Vector3f(0, 4f, 6f));
    cam.lookAt(new Vector3f(2, 2, 0), Vector3f.UNIT_Y);
    /** Initialize the scene, materials, inputs, and physics space */
    initInputs();
    initMaterials();
    initFloor();
    initCrossHairs();
  }

  /** Add InputManager action: Left click triggers shooting. */
  private void initInputs() {
    inputManager.addMapping("shoot", 
            new MouseButtonTrigger(MouseInput.BUTTON_LEFT));
    inputManager.addListener(actionListener, "shoot");
  }

  /** Initialize the materials used in this scene. */
  public void initMaterials() {
    stoneMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
    TextureKey key2 = new TextureKey("Textures/Terrain/Rock/Rock.PNG");
    key2.setGenerateMips(true);
    Texture tex2 = assetManager.loadTexture(key2);
    stoneMat.setTexture("ColorMap", tex2);

    floorMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
    TextureKey key3 = new TextureKey("Textures/Terrain/Pond/Pond.jpg");
    key3.setGenerateMips(true);
    Texture tex3 = assetManager.loadTexture(key3);
    tex3.setWrap(WrapMode.Repeat);
    floorMat.setTexture("ColorMap", tex3);
  }

  /** Make a solid floor and add it to the scene. */
  public void initFloor() {
    Geometry floorGeo = new Geometry("Floor", floor);
    floorGeo.setMaterial(floorMat);
    floorGeo.setLocalTranslation(0, -0.1f, 0);
    this.rootNode.attachChild(floorGeo);
    /* Make the floor physical with mass 0.0f! */
    floorPhy = new RigidBodyControl(0.0f);
    floorGeo.addControl(floorPhy);
    bulletAppState.getPhysicsSpace().add(floorPhy);
  }

  

  /** This method creates one individual physical cannon ball.
   * By defaul, the ball is accelerated and flies
   * from the camera position in the camera direction.*/
   public void makeCannonBall() {
    /** Create a cannon ball geometry and attach to scene graph. */
    Geometry ballGeo = new Geometry("cannon ball", sphere);
    ballGeo.setMaterial(stoneMat);
    rootNode.attachChild(ballGeo);
    /** Position the cannon ball  */
    //ballGeo.setLocalTranslation(new Vector3f(0,1,0));
     ballGeo.setLocalTranslation(cam.getLocation());
    float mass = 5; float g = 100;
    /** Make the ball physical with a mass > 0.0f */
    ballPhy = new RigidBodyControl(mass);
    /** Add physical ball to physics space. */
    ballGeo.addControl(ballPhy);
    bulletAppState.getPhysicsSpace().add(ballPhy);
    /** Accelerate the physical ball to shoot it. */
    ballPhy.setLinearVelocity(cam.getDirection().mult(g/mass));
    //ballPhy.setLinearVelocity(new Vector3f( 1, 0.5f,  0).mult(g/mass));
  }

  /** A plus sign used as crosshairs to help the player with aiming.*/
  protected void initCrossHairs() {
    setDisplayStatView(false);
    //guiFont = assetManager.loadFont("Interface/Fonts/Default.fnt");
    BitmapText ch = new BitmapText(guiFont, false);
    ch.setSize(guiFont.getCharSet().getRenderedSize() * 2);
    ch.setText("+");        // fake crosshairs :)
    ch.setLocalTranslation( // center
      settings.getWidth() / 2,
      settings.getHeight() / 2, 0);
    guiNode.attachChild(ch);
  }
}